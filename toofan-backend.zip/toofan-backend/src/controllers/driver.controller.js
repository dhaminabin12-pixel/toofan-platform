// ─────────────────────────────────────────────────────────────
//  Driver Controller  —  TooFan
//  Vehicle types: MOTORCYCLE | BICYCLE | CAR
//  Documents: Driving License, Number Plate/Registration,
//             Police Clearance, Profile Photo, Citizenship
//  Shift: max 10 hours/day, auto-block when limit hit
// ─────────────────────────────────────────────────────────────

const prisma         = require("../config/prisma");
const { AppError }   = require("../utils/appError");
const { asyncHandler } = require("../utils/asyncHandler");
const { calcDistance } = require("../utils/geo");
const { logger }     = require("../utils/logger");

const MAX_DAILY_HOURS = 10;

// ── Vehicle requirements by type ──────────────────────────────
const VEHICLE_REQUIREMENTS = {
  MOTORCYCLE: {
    label:        "Motorcycle",
    emoji:        "🏍️",
    maxWeight:    "15 kg per delivery",
    requiredDocs: ["profile_photo","license","registration","police_clearance","citizenship"],
    notes:        "Must have valid motorcycle license (category A). Bike must not be older than 10 years.",
  },
  BICYCLE: {
    label:        "Bicycle",
    emoji:        "🚲",
    maxWeight:    "8 kg per delivery",
    requiredDocs: ["profile_photo","license","police_clearance","citizenship"],
    notes:        "No engine license required — but cycling proficiency and police clearance mandatory. No number plate required.",
  },
  CAR: {
    label:        "Car",
    emoji:        "🚗",
    maxWeight:    "30 kg per delivery",
    requiredDocs: ["profile_photo","license","registration","police_clearance","citizenship"],
    notes:        "Must have valid car license (category B). Vehicle must not be older than 15 years.",
  },
};

// ── GET vehicle requirements (shown on registration screen) ──
exports.getVehicleRequirements = asyncHandler(async (req, res) => {
  res.json({ success: true, data: VEHICLE_REQUIREMENTS });
});

// ── APPLY AS DRIVER ───────────────────────────────────────────
exports.applyAsDriver = asyncHandler(async (req, res) => {
  const {
    vehicleType, vehicleNumber, vehicleName, vehicleColor, vehicleYear,
    licenseNumber, licenseExpiry,
    registrationNumber, registrationExpiry,
    citizenshipNo,
    deliveryZone, availableFrom, availableTo,
  } = req.body;

  // Validate vehicle type
  const validTypes = ["MOTORCYCLE", "BICYCLE", "CAR"];
  if (!validTypes.includes(vehicleType)) {
    throw new AppError("Invalid vehicle type. Must be MOTORCYCLE, BICYCLE, or CAR.", 400);
  }

  // Bicycle doesn't need registration
  if (vehicleType !== "BICYCLE" && !vehicleNumber) {
    throw new AppError("Number plate (vehicle number) is required for motorcycle and car.", 400);
  }

  const existing = await prisma.driver.findUnique({ where: { userId: req.user.id } });
  if (existing) throw new AppError("Driver application already submitted.", 409);

  const driver = await prisma.$transaction(async (tx) => {
    const d = await tx.driver.create({
      data: {
        userId:             req.user.id,
        vehicleType,
        vehicleNumber:      vehicleNumber   || "",
        vehicleName:        vehicleName     || null,
        vehicleColor:       vehicleColor    || null,
        vehicleYear:        vehicleYear     ? parseInt(vehicleYear) : null,
        licenseNumber,
        licenseExpiry:      new Date(licenseExpiry),
        registrationNumber: registrationNumber || null,
        registrationExpiry: registrationExpiry ? new Date(registrationExpiry) : null,
        citizenshipNo,
        deliveryZone:       deliveryZone    || null,
        availableFrom:      availableFrom   || "08:00",
        availableTo:        availableTo     || "22:00",
        status:             "PENDING_APPROVAL",
      }
    });

    // Update user role
    await tx.user.update({
      where: { id: req.user.id },
      data:  { role: "DRIVER" }
    });

    return d;
  });

  logger.info(`New driver application: ${req.user.name} [${vehicleType}]`);

  res.status(201).json({
    success: true,
    message: "Application submitted. Please upload your documents next.",
    data: {
      driver,
      nextSteps: VEHICLE_REQUIREMENTS[vehicleType].requiredDocs.map(doc => ({
        doc,
        label: getDocLabel(doc),
        uploaded: false,
      }))
    }
  });
});

// ── UPLOAD DOCUMENT ───────────────────────────────────────────
// Called after each document upload (multer handles the file in route)
exports.uploadDocument = asyncHandler(async (req, res) => {
  const { docType } = req.body;
  const fileUrl = req.uploadedFileUrl; // set by upload middleware in route

  const validDocTypes = ["profile_photo","license_front","license_back","registration","police_clearance","citizenship_front","citizenship_back","vehicle_photo"];
  if (!validDocTypes.includes(docType)) {
    throw new AppError("Invalid document type.", 400);
  }

  const driver = await prisma.driver.findUnique({ where: { userId: req.user.id } });
  if (!driver) throw new AppError("Driver profile not found. Apply first.", 404);

  // Map docType to driver fields
  const fieldMap = {
    profile_photo:       { profilePhotoUrl: fileUrl, profilePhotoApproved: false },
    license_front:       { licensePhotoFront: fileUrl, licenseStatus: "PENDING_REVIEW" },
    license_back:        { licensePhotoBack: fileUrl },
    registration:        { registrationPhotoUrl: fileUrl, registrationStatus: "PENDING_REVIEW" },
    police_clearance:    { policeClearanceUrl: fileUrl, policeClearanceStatus: "PENDING_REVIEW" },
    citizenship_front:   { citizenshipPhotoFront: fileUrl },
    citizenship_back:    { citizenshipPhotoBack: fileUrl },
    vehicle_photo:       { vehiclePhotoUrl: fileUrl },
  };

  await prisma.$transaction(async (tx) => {
    // Update driver record
    await tx.driver.update({
      where: { id: driver.id },
      data:  fieldMap[docType]
    });

    // Log the document submission
    await tx.driverDocumentLog.create({
      data: {
        driverId:   driver.id,
        docType,
        fileUrl,
        status:     "PENDING_REVIEW",
      }
    });
  });

  // Check if all required docs are now submitted → auto-notify admin
  const updated = await prisma.driver.findUnique({ where: { id: driver.id } });
  const requirements = VEHICLE_REQUIREMENTS[driver.vehicleType].requiredDocs;
  const allSubmitted = checkAllDocsSubmitted(updated, requirements);

  if (allSubmitted) {
    logger.info(`Driver ${driver.id} submitted all docs — ready for admin review`);
  }

  res.json({
    success:     true,
    message:     `${getDocLabel(docType)} uploaded successfully. Pending admin review.`,
    data:        { docType, fileUrl, allDocsSubmitted: allSubmitted }
  });
});

// ── GET MY PROFILE (full document status) ────────────────────
exports.getMyProfile = asyncHandler(async (req, res) => {
  const driver = await prisma.driver.findUnique({
    where:   { userId: req.user.id },
    include: {
      user:         { select: { name: true, phone: true, email: true, avatarUrl: true } },
      documentLogs: { orderBy: { submittedAt: "desc" }, take: 20 }
    }
  });
  if (!driver) throw new AppError("Driver profile not found.", 404);

  const requirements = VEHICLE_REQUIREMENTS[driver.vehicleType];
  const docStatus    = buildDocStatus(driver);
  const shiftStatus  = buildShiftStatus(driver);

  res.json({
    success: true,
    data: {
      ...driver,
      vehicleRequirements: requirements,
      documentStatus:      docStatus,
      shiftStatus,
    }
  });
});

// ── UPDATE PROFILE ─────────────────────────────────────────── 
exports.updateProfile = asyncHandler(async (req, res) => {
  const { vehicleName, vehicleColor, deliveryZone, availableFrom, availableTo } = req.body;
  const driver = await prisma.driver.findUnique({ where: { userId: req.user.id } });
  if (!driver) throw new AppError("Driver not found.", 404);

  const data = {};
  if (vehicleName   !== undefined) data.vehicleName   = vehicleName;
  if (vehicleColor  !== undefined) data.vehicleColor  = vehicleColor;
  if (deliveryZone  !== undefined) data.deliveryZone  = deliveryZone;
  if (availableFrom !== undefined) data.availableFrom = availableFrom;
  if (availableTo   !== undefined) data.availableTo   = availableTo;

  const updated = await prisma.driver.update({ where: { id: driver.id }, data });
  res.json({ success: true, data: updated });
});

// ── GO ONLINE (start shift) ───────────────────────────────────
exports.goOnline = asyncHandler(async (req, res) => {
  const driver = await prisma.driver.findUnique({ where: { userId: req.user.id } });
  if (!driver) throw new AppError("Driver profile not found.", 404);

  // Must be approved
  if (driver.status === "PENDING_APPROVAL") {
    throw new AppError("Your application is pending review. You cannot go online yet.", 403);
  }
  if (driver.status === "SUSPENDED") {
    throw new AppError("Your account is suspended. Contact support.", 403);
  }

  // Check profile photo approved
  if (!driver.profilePhotoApproved) {
    throw new AppError("Your profile photo must be approved before going online.", 403);
  }

  // Check 10-hour daily limit
  const todayHours = await getTodayHours(driver);
  if (todayHours >= MAX_DAILY_HOURS) {
    throw new AppError(
      `You have reached the ${MAX_DAILY_HOURS}-hour daily driving limit. You can go online again tomorrow.`,
      403
    );
  }

  const remaining = MAX_DAILY_HOURS - todayHours;

  await prisma.$transaction(async (tx) => {
    await tx.driver.update({
      where: { id: driver.id },
      data:  { isOnline: true, shiftStartedAt: new Date(), status: "APPROVED" }
    });
    await tx.driverShiftLog.create({
      data: { driverId: driver.id }
    });
  });

  res.json({
    success: true,
    message: "You are now online and in the dispatch pool.",
    data: {
      isOnline:          true,
      todayHoursUsed:    Math.round(todayHours * 10) / 10,
      hoursRemaining:    Math.round(remaining * 10) / 10,
      maxDailyHours:     MAX_DAILY_HOURS,
    }
  });
});

// ── GO OFFLINE (end shift) ────────────────────────────────────
exports.goOffline = asyncHandler(async (req, res) => {
  const driver = await prisma.driver.findUnique({ where: { userId: req.user.id } });
  if (!driver) throw new AppError("Driver not found.", 404);

  const hoursThisSession = driver.shiftStartedAt
    ? (Date.now() - new Date(driver.shiftStartedAt).getTime()) / (1000 * 60 * 60)
    : 0;

  const todayHours = await getTodayHours(driver) + hoursThisSession;

  await prisma.$transaction(async (tx) => {
    await tx.driver.update({
      where: { id: driver.id },
      data:  {
        isOnline:         false,
        shiftStartedAt:   null,
        todayOnlineHours: todayHours,
        lastShiftDate:    new Date(),
        currentLat:       null,
        currentLng:       null,
      }
    });

    // Close the latest open shift log
    const openLog = await tx.driverShiftLog.findFirst({
      where:   { driverId: driver.id, endedAt: null },
      orderBy: { startedAt: "desc" }
    });
    if (openLog) {
      await tx.driverShiftLog.update({
        where: { id: openLog.id },
        data:  {
          endedAt:      new Date(),
          hoursWorked:  Math.round(hoursThisSession * 100) / 100,
          tripsInShift: driver.todayTrips,
          earnedInShift: driver.todayEarnings,
        }
      });
    }
  });

  res.json({
    success: true,
    message: "Shift ended. Good work today!",
    data: {
      isOnline:       false,
      hoursToday:     Math.round(todayHours * 10) / 10,
      tripsToday:     driver.todayTrips,
      earningsToday:  driver.todayEarnings,
    }
  });
});

// ── CHECK SHIFT STATUS ────────────────────────────────────────
exports.getShiftStatus = asyncHandler(async (req, res) => {
  const driver = await prisma.driver.findUnique({ where: { userId: req.user.id } });
  if (!driver) throw new AppError("Not found.", 404);

  const shiftStatus = buildShiftStatus(driver);
  const todayHours  = await getTodayHours(driver);

  res.json({ success: true, data: { ...shiftStatus, todayHoursAccumulated: todayHours } });
});

// ── GET EARNINGS ──────────────────────────────────────────────
exports.getEarnings = asyncHandler(async (req, res) => {
  const driver = await prisma.driver.findUnique({ where: { userId: req.user.id } });
  if (!driver) throw new AppError("Not found.", 404);

  const today      = new Date(); today.setHours(0,0,0,0);
  const weekStart  = new Date(); weekStart.setDate(weekStart.getDate() - 7);
  const monthStart = new Date(); monthStart.setDate(1); monthStart.setHours(0,0,0,0);

  const [todayAgg, weekAgg, monthAgg, recent] = await Promise.all([
    prisma.driverEarning.aggregate({ where: { driverId: driver.id, date: { gte: today } },      _sum: { amount: true } }),
    prisma.driverEarning.aggregate({ where: { driverId: driver.id, date: { gte: weekStart } },  _sum: { amount: true } }),
    prisma.driverEarning.aggregate({ where: { driverId: driver.id, date: { gte: monthStart } }, _sum: { amount: true } }),
    prisma.driverEarning.findMany({ where: { driverId: driver.id }, orderBy: { date: "desc" }, take: 20 }),
  ]);

  const todayTrips = await prisma.driverTrip.count({ where: { driverId: driver.id, completedAt: { gte: today } } });

  res.json({
    success: true,
    data: {
      today:   { amount: todayAgg._sum.amount || 0, trips: todayTrips },
      week:    { amount: weekAgg._sum.amount  || 0 },
      month:   { amount: monthAgg._sum.amount || 0 },
      allTime: { amount: driver.totalEarnings,  trips: driver.totalTrips },
      recent,
    }
  });
});

// ── GET TRIP HISTORY ──────────────────────────────────────────
exports.getTripHistory = asyncHandler(async (req, res) => {
  const { page = 1, limit = 20, date } = req.query;
  const driver = await prisma.driver.findUnique({ where: { userId: req.user.id } });
  if (!driver) throw new AppError("Not found.", 404);

  let where = { driverId: driver.id };
  if (date) {
    const s = new Date(date); s.setHours(0,0,0,0);
    const e = new Date(date); e.setHours(23,59,59,999);
    where.completedAt = { gte: s, lte: e };
  }

  const [trips, total] = await Promise.all([
    prisma.driverTrip.findMany({
      where,
      include: { order: { include: { restaurant: { select: { name: true } } } } },
      orderBy: { completedAt: "desc" },
      skip:    (parseInt(page)-1) * parseInt(limit),
      take:    parseInt(limit),
    }),
    prisma.driverTrip.count({ where })
  ]);

  res.json({ success: true, data: { trips, total } });
});

// ── GET INCENTIVES ────────────────────────────────────────────
exports.getIncentives = asyncHandler(async (req, res) => {
  const driver = await prisma.driver.findUnique({ where: { userId: req.user.id } });
  if (!driver) throw new AppError("Not found.", 404);

  const today = new Date(); today.setHours(0,0,0,0);
  const weekStart = new Date(); weekStart.setDate(weekStart.getDate() - weekStart.getDay()); weekStart.setHours(0,0,0,0);

  const [todayTrips, weekEarnings] = await Promise.all([
    prisma.driverTrip.count({ where: { driverId: driver.id, completedAt: { gte: today } } }),
    prisma.driverEarning.aggregate({ where: { driverId: driver.id, date: { gte: weekStart } }, _sum: { amount: true } }),
  ]);

  const todayHours = await getTodayHours(driver);

  const incentives = [
    { type:"rain_bonus",  title:"Rain Bonus",        desc:"1.5x earnings in heavy rain",          earn:"+50%",  status:"Active"           },
    { type:"rush_hour",   title:"Rush Hour",           desc:"Extra रू20 per delivery 6–9 PM",      earn:"+रू20", status:"Active"           },
    { type:"streak_10",   title:"10-Trip Streak",      desc:"रू200 bonus for 10 trips today",       earn:"+रू200",status:`${todayTrips}/10` },
    { type:"long_pickup", title:"Long Pickup Bonus",   desc:"रू30 extra for pickups >3 km away",   earn:"+रू30", status:"Active"           },
  ];

  const weeklyTarget = 5000;
  const weeklyEarned = weekEarnings._sum.amount || 0;

  res.json({
    success: true,
    data: {
      incentives,
      weekly:           { target: weeklyTarget, earned: weeklyEarned, bonus: 500 },
      todayTrips,
      todayHours:       Math.round(todayHours * 10) / 10,
      hoursRemaining:   Math.round((MAX_DAILY_HOURS - todayHours) * 10) / 10,
      cancellationRate: 4.2,
    }
  });
});

// ── GET SURGE ZONES ───────────────────────────────────────────
exports.getSurgeZones = asyncHandler(async (req, res) => {
  const zones = await prisma.surgeZone.findMany({ where: { isActive: true } });
  res.json({ success: true, data: zones });
});

// ── GET NEARBY DRIVERS ────────────────────────────────────────
exports.getNearbyDrivers = asyncHandler(async (req, res) => {
  const { lat, lng, radius = 5, vehicleType } = req.query;
  if (!lat || !lng) throw new AppError("lat and lng required.", 400);

  let where = { isOnline: true, currentLat: { not: null } };
  if (vehicleType) where.vehicleType = vehicleType;

  const drivers = await prisma.driver.findMany({
    where,
    include: { user: { select: { name: true } } }
  });

  const nearby = drivers
    .map(d => ({ ...d, distKm: calcDistance(parseFloat(lat), parseFloat(lng), d.currentLat, d.currentLng) }))
    .filter(d => d.distKm <= parseFloat(radius))
    .sort((a,b) => a.distKm - b.distKm);

  res.json({ success: true, data: nearby });
});

// ── LIST ALL DRIVERS (admin) ──────────────────────────────────
exports.listDrivers = asyncHandler(async (req, res) => {
  const { status, vehicleType, page = 1, limit = 20 } = req.query;
  let where = {};
  if (status)      where.status      = status;
  if (vehicleType) where.vehicleType = vehicleType;

  const [drivers, total] = await Promise.all([
    prisma.driver.findMany({
      where,
      include: { user: { select: { name: true, phone: true, email: true } } },
      orderBy: { createdAt: "desc" },
      skip:    (parseInt(page)-1) * parseInt(limit),
      take:    parseInt(limit),
    }),
    prisma.driver.count({ where })
  ]);

  res.json({ success: true, data: { drivers, total } });
});

// ── ADMIN: REVIEW DOCUMENT ────────────────────────────────────
exports.reviewDocument = asyncHandler(async (req, res) => {
  const { driverId, docType, action, note } = req.body;
  // action: "approve" | "reject"

  if (!["approve","reject"].includes(action)) {
    throw new AppError("action must be approve or reject.", 400);
  }

  const driver = await prisma.driver.findUnique({ where: { id: driverId } });
  if (!driver) throw new AppError("Driver not found.", 404);

  const newStatus = action === "approve" ? "APPROVED" : "REJECTED";

  // Map docType to driver status field
  const statusFieldMap = {
    profile_photo:    { profilePhotoApproved: action === "approve" },
    license_front:    { licenseStatus: newStatus },
    license_back:     { licenseStatus: newStatus },
    registration:     { registrationStatus: newStatus },
    police_clearance: { policeClearanceStatus: newStatus },
  };

  await prisma.$transaction(async (tx) => {
    if (statusFieldMap[docType]) {
      await tx.driver.update({
        where: { id: driverId },
        data:  statusFieldMap[docType]
      });
    }

    // Update the document log
    await tx.driverDocumentLog.updateMany({
      where: { driverId, docType, status: "PENDING_REVIEW" },
      data:  {
        status:     newStatus,
        reviewNote: note || null,
        reviewedBy: req.user.id,
        reviewedAt: new Date(),
      }
    });
  });

  // Check if all required docs now approved → auto-approve driver
  const refreshed = await prisma.driver.findUnique({ where: { id: driverId } });
  const requirements = VEHICLE_REQUIREMENTS[refreshed.vehicleType].requiredDocs;
  const allApproved  = checkAllDocsApproved(refreshed, requirements);

  if (allApproved && refreshed.status === "PENDING_APPROVAL") {
    await prisma.driver.update({
      where: { id: driverId },
      data:  { status: "APPROVED", approvedAt: new Date(), approvedBy: req.user.id }
    });
    logger.info(`Driver ${driverId} auto-approved — all documents verified`);
  }

  res.json({
    success: true,
    message: `Document ${action}d successfully.${allApproved ? " Driver account fully approved!" : ""}`,
    data:    { allDocsApproved: allApproved }
  });
});

// ── ADMIN: APPROVE DRIVER ─────────────────────────────────────
exports.approveDriver = asyncHandler(async (req, res) => {
  const driver = await prisma.driver.update({
    where: { id: req.params.id },
    data:  { status: "APPROVED", approvedAt: new Date(), approvedBy: req.user.id }
  });
  res.json({ success: true, message: "Driver approved.", data: driver });
});

// ── ADMIN: SUSPEND DRIVER ─────────────────────────────────────
exports.suspendDriver = asyncHandler(async (req, res) => {
  const { reason } = req.body;
  const driver = await prisma.driver.update({
    where: { id: req.params.id },
    data:  { status: "SUSPENDED", isOnline: false, adminNotes: reason || null }
  });
  res.json({ success: true, message: "Driver suspended.", data: driver });
});

// ── ADMIN: GET DRIVER DETAIL ──────────────────────────────────
exports.getDriverDetail = asyncHandler(async (req, res) => {
  const driver = await prisma.driver.findUnique({
    where:   { id: req.params.id },
    include: {
      user:         { select: { name: true, phone: true, email: true } },
      documentLogs: { orderBy: { submittedAt: "desc" } },
      shiftLogs:    { orderBy: { startedAt: "desc" }, take: 10 },
    }
  });
  if (!driver) throw new AppError("Driver not found.", 404);

  const docStatus   = buildDocStatus(driver);
  const shiftStatus = buildShiftStatus(driver);

  res.json({ success: true, data: { ...driver, documentStatus: docStatus, shiftStatus } });
});

// ── HELPERS ───────────────────────────────────────────────────

async function getTodayHours(driver) {
  const today = new Date(); today.setHours(0,0,0,0);

  // If last shift was not today, hours reset to 0
  if (driver.lastShiftDate && new Date(driver.lastShiftDate) < today) {
    // Reset today hours
    await prisma.driver.update({
      where: { id: driver.id },
      data:  { todayOnlineHours: 0, todayTrips: 0, todayEarnings: 0 }
    });
    return 0;
  }

  let hours = driver.todayOnlineHours || 0;

  // Add current session if online
  if (driver.isOnline && driver.shiftStartedAt) {
    const sessionHours = (Date.now() - new Date(driver.shiftStartedAt).getTime()) / (1000 * 60 * 60);
    hours += sessionHours;
  }

  return hours;
}

function buildDocStatus(driver) {
  const requirements = VEHICLE_REQUIREMENTS[driver.vehicleType]?.requiredDocs || [];
  return requirements.map(doc => {
    const { submitted, status, url } = getDocState(driver, doc);
    return { doc, label: getDocLabel(doc), submitted, status, url };
  });
}

function getDocState(driver, docType) {
  const map = {
    profile_photo:    { submitted: !!driver.profilePhotoUrl,    status: driver.profilePhotoApproved ? "APPROVED" : (driver.profilePhotoUrl ? "PENDING_REVIEW" : "NOT_SUBMITTED"),  url: driver.profilePhotoUrl    },
    license:          { submitted: !!driver.licensePhotoFront,  status: driver.licenseStatus,        url: driver.licensePhotoFront  },
    registration:     { submitted: !!driver.registrationPhotoUrl, status: driver.registrationStatus, url: driver.registrationPhotoUrl },
    police_clearance: { submitted: !!driver.policeClearanceUrl, status: driver.policeClearanceStatus, url: driver.policeClearanceUrl },
    citizenship:      { submitted: !!driver.citizenshipPhotoFront, status: driver.citizenshipPhotoFront ? "PENDING_REVIEW" : "NOT_SUBMITTED", url: driver.citizenshipPhotoFront },
  };
  return map[docType] || { submitted: false, status: "NOT_SUBMITTED", url: null };
}

function buildShiftStatus(driver) {
  const hoursUsed  = driver.todayOnlineHours || 0;
  const remaining  = Math.max(0, MAX_DAILY_HOURS - hoursUsed);
  const limitHit   = hoursUsed >= MAX_DAILY_HOURS;

  return {
    isOnline:      driver.isOnline,
    todayHours:    Math.round(hoursUsed * 10) / 10,
    hoursRemaining: Math.round(remaining * 10) / 10,
    maxDailyHours: MAX_DAILY_HOURS,
    limitHit,
    shiftStartedAt: driver.shiftStartedAt,
    message: limitHit
      ? `You have completed your ${MAX_DAILY_HOURS}-hour daily limit. Rest and come back tomorrow!`
      : `You have ${Math.round(remaining * 10) / 10} hours remaining today.`,
  };
}

function checkAllDocsSubmitted(driver, requirements) {
  return requirements.every(doc => {
    const { submitted } = getDocState(driver, doc);
    return submitted;
  });
}

function checkAllDocsApproved(driver, requirements) {
  const checkMap = {
    profile_photo:    driver.profilePhotoApproved,
    license:          driver.licenseStatus         === "APPROVED",
    registration:     driver.registrationStatus    === "APPROVED",
    police_clearance: driver.policeClearanceStatus === "APPROVED",
    citizenship:      !!driver.citizenshipPhotoFront,
  };
  return requirements.every(doc => checkMap[doc] === true);
}

function getDocLabel(docType) {
  const labels = {
    profile_photo:       "Profile Photo (clear face)",
    license:             "Driving License (front & back)",
    license_front:       "Driving License (front)",
    license_back:        "Driving License (back)",
    registration:        "Vehicle Registration / Number Plate",
    police_clearance:    "Police Clearance Certificate",
    citizenship:         "Citizenship Card",
    citizenship_front:   "Citizenship Card (front)",
    citizenship_back:    "Citizenship Card (back)",
    vehicle_photo:       "Vehicle Photo",
  };
  return labels[docType] || docType;
}
