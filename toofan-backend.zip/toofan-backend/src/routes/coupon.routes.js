// ─────────────────────────────────────────────────────────────
//  Coupon Routes  —  /api/v1/coupons
// ─────────────────────────────────────────────────────────────

const router   = require("express").Router();
const { body } = require("express-validator");
const prisma   = require("../config/prisma");
const { authenticate } = require("../middleware/auth.middleware");
const { authorize }    = require("../middleware/authorize.middleware");
const { validate }     = require("../middleware/validate.middleware");
const { asyncHandler } = require("../utils/asyncHandler");
const { AppError }     = require("../utils/appError");

router.use(authenticate);

// GET /coupons/validate/:code  — validate before applying at checkout
router.get("/validate/:code", asyncHandler(async (req, res) => {
  const coupon = await prisma.coupon.findFirst({
    where: {
      code:     req.params.code.toUpperCase().trim(),
      isActive: true,
      OR: [{ expiresAt: null }, { expiresAt: { gt: new Date() } }],
    }
  });

  if (!coupon || coupon.usageCount >= coupon.usageLimit) {
    throw new AppError("Invalid or expired coupon code.", 400);
  }

  res.json({
    success: true,
    data: {
      code:        coupon.code,
      type:        coupon.type,
      value:       coupon.value,
      maxDiscount: coupon.maxDiscount,
      description: coupon.description,
      minOrder:    coupon.minOrderAmount,
    }
  });
}));

// GET /coupons  — list all (admin/partner)
router.get("/", authorize("SUPER_ADMIN","PARTNER_ADMIN"), asyncHandler(async (req, res) => {
  const coupons = await prisma.coupon.findMany({ orderBy: { createdAt: "desc" } });
  res.json({ success: true, data: coupons });
}));

// POST /coupons  — create (admin/partner)
router.post("/",
  authorize("SUPER_ADMIN","PARTNER_ADMIN"),
  [
    body("code").notEmpty().trim().toUpperCase(),
    body("description").notEmpty(),
    body("type").isIn(["pct","flat"]).withMessage("type must be pct or flat"),
    body("value").isFloat({ min: 1 }).withMessage("value must be a positive number"),
  ],
  validate,
  asyncHandler(async (req, res) => {
    const { code, description, type, value, maxDiscount, usageLimit, minOrderAmount, expiresAt } = req.body;

    const existing = await prisma.coupon.findUnique({ where: { code: code.toUpperCase() } });
    if (existing) throw new AppError("Coupon code already exists.", 409);

    const coupon = await prisma.coupon.create({
      data: {
        code:           code.toUpperCase().trim(),
        description,
        type,
        value:          parseFloat(value),
        maxDiscount:    maxDiscount    ? parseFloat(maxDiscount)    : null,
        usageLimit:     usageLimit     ? parseInt(usageLimit)       : 100,
        minOrderAmount: minOrderAmount ? parseFloat(minOrderAmount) : 0,
        expiresAt:      expiresAt      ? new Date(expiresAt)        : null,
      }
    });
    res.status(201).json({ success: true, data: coupon });
  })
);

// PATCH /coupons/:id  — update (admin)
router.patch("/:id", authorize("SUPER_ADMIN"), asyncHandler(async (req, res) => {
  const { isActive, usageLimit, expiresAt, description } = req.body;
  const data = {};
  if (isActive !== undefined)   data.isActive   = isActive;
  if (usageLimit !== undefined) data.usageLimit = parseInt(usageLimit);
  if (expiresAt !== undefined)  data.expiresAt  = new Date(expiresAt);
  if (description !== undefined) data.description = description;
  const coupon = await prisma.coupon.update({ where: { id: req.params.id }, data });
  res.json({ success: true, data: coupon });
}));

// DELETE /coupons/:id  — soft delete (admin)
router.delete("/:id", authorize("SUPER_ADMIN"), asyncHandler(async (req, res) => {
  await prisma.coupon.update({ where: { id: req.params.id }, data: { isActive: false } });
  res.json({ success: true, message: "Coupon deactivated." });
}));

module.exports = router;
