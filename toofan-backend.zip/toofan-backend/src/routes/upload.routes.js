// ─────────────────────────────────────────────────────────────
//  Upload Routes  —  /api/v1/uploads
// ─────────────────────────────────────────────────────────────

const router  = require("express").Router();
const multer  = require("multer");
const path    = require("path");
const fs      = require("fs");
const { authenticate } = require("../middleware/auth.middleware");
const { AppError }     = require("../utils/appError");

router.use(authenticate);

// Ensure uploads directory exists
const uploadDir = path.join(__dirname, "../../uploads");
if (!fs.existsSync(uploadDir)) fs.mkdirSync(uploadDir, { recursive: true });

// Multer config — local disk storage
const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, uploadDir),
  filename:    (req, file, cb) => {
    const unique = `${Date.now()}-${Math.random().toString(36).slice(2)}`;
    const ext    = path.extname(file.originalname).toLowerCase();
    cb(null, `${unique}${ext}`);
  },
});

const upload = multer({
  storage,
  limits: { fileSize: 5 * 1024 * 1024 }, // 5MB max
  fileFilter: (req, file, cb) => {
    const allowed = ["image/jpeg", "image/jpg", "image/png", "image/webp"];
    if (allowed.includes(file.mimetype)) {
      cb(null, true);
    } else {
      cb(new AppError("Only JPEG, PNG and WebP images are allowed.", 400), false);
    }
  },
});

// POST /uploads/image  — single image upload
router.post("/image", upload.single("image"), (req, res, next) => {
  try {
    if (!req.file) throw new AppError("No file uploaded.", 400);
    const url = `${req.protocol}://${req.get("host")}/uploads/${req.file.filename}`;
    res.json({
      success: true,
      data: {
        url,
        filename:  req.file.filename,
        size:      req.file.size,
        mimetype:  req.file.mimetype,
      }
    });
  } catch (err) {
    next(err);
  }
});

// POST /uploads/multiple  — up to 5 images
router.post("/multiple", upload.array("images", 5), (req, res, next) => {
  try {
    if (!req.files?.length) throw new AppError("No files uploaded.", 400);
    const urls = req.files.map(f => ({
      url:      `${req.protocol}://${req.get("host")}/uploads/${f.filename}`,
      filename: f.filename,
    }));
    res.json({ success: true, data: urls });
  } catch (err) {
    next(err);
  }
});

module.exports = router;
