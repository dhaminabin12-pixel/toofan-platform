// ─────────────────────────────────────────────────────────────
//  Driver Routes  —  /api/v1/drivers
// ─────────────────────────────────────────────────────────────

const router   = require("express").Router();
const { body, param, query } = require("express-validator");
const multer   = require("multer");
const path     = require("path");
const fs       = require("fs");
const controller = require("../controllers/driver.controller");
const { authenticate }  = require("../middleware/auth.middleware");
const { authorize }     = require("../middleware/authorize.middleware");
const { validate }      = require("../middleware/validate.middleware");
const { asyncHandler }  = require("../utils/asyncHandler");
const { AppError }      = require("../utils/appError");

// ── MULTER for document uploads ───────────────────────────────
const uploadDir = path.join(__dirname, "../../uploads/drivers");
if (!fs.existsSync(uploadDir)) fs.mkdirSync(uploadDir, { recursive: true });

const docStorage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, uploadDir),
  filename:    (req, file, cb) => {
    const ext    = path.extname(file.originalname).toLowerCase();
    const unique = `driver_${req.user?.id}_${req.body?.docType}_${Date.now()}${ext}`;
    cb(null, unique);
  },
});

const docUpload = multer({
  storage:    docStorage,
  limits:     { fileSize: 10 * 1024 * 1024 }, // 10MB for document photos
  fileFilter: (req, file, cb) => {
    const allowed = ["image/jpeg","image/jpg","image/png","image/webp","application/pdf"];
    allowed.includes(file.mimetype) ? cb(null, true) : cb(new AppError("Only images and PDFs allowed.", 400), false);
  },
});

// Middleware: attach uploaded URL to req after multer
const attachFileUrl = (req, res, next) => {
  if (req.file) {
    req.uploadedFileUrl = `${req.protocol}://${req.get("host")}/uploads/drivers/${req.file.filename}`;
  }
  next();
};

router.use(authenticate);

// ── PUBLIC INFO ───────────────────────────────────────────────

// GET /drivers/vehicle-requirements
// Returns what documents each vehicle type needs
router.get("/vehicle-requirements", controller.getVehicleRequirements);

// GET /drivers/surge-zones
router.get("/surge-zones", controller.getSurgeZones);

// ── MY PROFILE ────────────────────────────────────────────────

// POST /drivers/apply  — Submit driver application
router.post("/apply",
  [
    body("vehicleType").isIn(["MOTORCYCLE","BICYCLE","CAR"]).withMessage("vehicleType must be MOTORCYCLE, BICYCLE, or CAR"),
    body("licenseNumber").notEmpty().withMessage("Driving license number required"),
    body("licenseExpiry").isISO8601().withMessage("Valid license expiry date required"),
    body("citizenshipNo").notEmpty().withMessage("Citizenship number required"),
    body("vehicleNumber").optional().trim(),
    body("vehicleName").optional().trim(),
    body("vehicleColor").optional().trim(),
    body("vehicleYear").optional().isInt({ min: 1990, max: new Date().getFullYear() }),
    body("registrationNumber").optional().trim(),
    body("deliveryZone").optional().trim(),
    body("availableFrom").optional().matches(/^\d{2}:\d{2}$/),
    body("availableTo").optional().matches(/^\d{2}:\d{2}$/),
  ],
  validate,
  controller.applyAsDriver
);

// POST /drivers/documents  — Upload a single document
// Field: "document" (the file), body: { docType }
router.post("/documents",
  docUpload.single("document"),
  attachFileUrl,
  [
    body("docType").isIn([
      "profile_photo",
      "license_front","license_back",
      "registration",
      "police_clearance",
      "citizenship_front","citizenship_back",
      "vehicle_photo",
    ]).withMessage("Invalid document type"),
  ],
  validate,
  controller.uploadDocument
);

// GET /drivers/me
router.get("/me", authorize("DRIVER"), controller.getMyProfile);

// PATCH /drivers/me
router.patch("/me", authorize("DRIVER"), controller.updateProfile);

// POST /drivers/me/online  — Start shift (go online)
router.post("/me/online", authorize("DRIVER"), controller.goOnline);

// POST /drivers/me/offline  — End shift (go offline)
router.post("/me/offline", authorize("DRIVER"), controller.goOffline);

// GET /drivers/me/shift  — Current shift status + hours today
router.get("/me/shift", authorize("DRIVER"), controller.getShiftStatus);

// GET /drivers/me/earnings
router.get("/me/earnings", authorize("DRIVER"), controller.getEarnings);

// GET /drivers/me/trips
router.get("/me/trips", authorize("DRIVER"), controller.getTripHistory);

// GET /drivers/me/incentives
router.get("/me/incentives", authorize("DRIVER"), controller.getIncentives);

// ── ADMIN ─────────────────────────────────────────────────────

// GET /drivers  — list all (admin)
router.get("/",
  authorize("SUPER_ADMIN","PARTNER_ADMIN"),
  controller.listDrivers
);

// GET /drivers/nearby  — nearby online drivers
router.get("/nearby",
  authorize("SUPER_ADMIN","PARTNER_ADMIN"),
  [
    query("lat").isFloat().withMessage("lat required"),
    query("lng").isFloat().withMessage("lng required"),
  ],
  validate,
  controller.getNearbyDrivers
);

// GET /drivers/:id  — full driver detail with docs + shifts
router.get("/:id",
  authorize("SUPER_ADMIN","PARTNER_ADMIN"),
  [param("id").isUUID()],
  validate,
  controller.getDriverDetail
);

// PATCH /drivers/:id/approve
router.patch("/:id/approve",
  authorize("SUPER_ADMIN"),
  [param("id").isUUID()],
  validate,
  controller.approveDriver
);

// PATCH /drivers/:id/suspend
router.patch("/:id/suspend",
  authorize("SUPER_ADMIN"),
  [param("id").isUUID(), body("reason").optional().trim()],
  validate,
  controller.suspendDriver
);

// POST /drivers/documents/review  — Admin reviews a document
router.post("/documents/review",
  authorize("SUPER_ADMIN"),
  [
    body("driverId").isUUID().withMessage("Valid driverId required"),
    body("docType").notEmpty().withMessage("docType required"),
    body("action").isIn(["approve","reject"]).withMessage("action must be approve or reject"),
    body("note").optional().trim(),
  ],
  validate,
  controller.reviewDocument
);

module.exports = router;
