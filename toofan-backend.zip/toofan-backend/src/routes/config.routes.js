// ─────────────────────────────────────────────────────────────
//  Config Routes  —  /api/v1/config
//  Public endpoint — apps fetch their runtime config on startup
// ─────────────────────────────────────────────────────────────

const router   = require("express").Router();
const prisma   = require("../config/prisma");
const { asyncHandler } = require("../utils/asyncHandler");

// GET /config/:app  — fetch all config for an app
// e.g. GET /config/khana returns { deliveryFee: "50", platformFee: "20", ... }
router.get("/:app", asyncHandler(async (req, res) => {
  const validApps = ["khana", "driver", "business", "admin"];
  if (!validApps.includes(req.params.app)) {
    return res.status(400).json({ success: false, message: "Invalid app name." });
  }

  const configs = await prisma.appConfig.findMany({
    where: { app: req.params.app }
  });

  // Return as flat key-value object — easy to consume on frontend
  const obj = Object.fromEntries(configs.map(c => [c.key, c.value]));
  res.json({ success: true, data: obj });
}));

module.exports = router;
