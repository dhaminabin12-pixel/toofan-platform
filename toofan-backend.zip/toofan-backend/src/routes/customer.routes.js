// ─────────────────────────────────────────────────────────────
//  Customer Routes  —  /api/v1/customers
// ─────────────────────────────────────────────────────────────

const router   = require("express").Router();
const { body } = require("express-validator");
const prisma   = require("../config/prisma");
const { authenticate } = require("../middleware/auth.middleware");
const { authorize }    = require("../middleware/authorize.middleware");
const { validate }     = require("../middleware/validate.middleware");
const { asyncHandler } = require("../utils/asyncHandler");
const { AppError }     = require("../utils/appError");

router.use(authenticate);

// GET /customers/me  — profile + wallet + coins
router.get("/me", authorize("CUSTOMER"), asyncHandler(async (req, res) => {
  const customer = await prisma.customer.findUnique({
    where:   { userId: req.user.id },
    include: {
      addresses:  { orderBy: { isDefault: "desc" } },
      user:       { select: { name: true, phone: true, email: true, avatarUrl: true, isVerified: true } },
    }
  });
  if (!customer) throw new AppError("Customer profile not found.", 404);
  res.json({ success: true, data: customer });
}));

// GET /customers/me/orders  — order history
router.get("/me/orders", authorize("CUSTOMER"), asyncHandler(async (req, res) => {
  const { page = 1, limit = 20 } = req.query;
  const customer = await prisma.customer.findUnique({ where: { userId: req.user.id } });

  const [orders, total] = await Promise.all([
    prisma.order.findMany({
      where:   { customerId: customer.id },
      include: {
        items:      true,
        restaurant: { select: { name: true, imageUrl: true } },
      },
      orderBy: { createdAt: "desc" },
      skip:    (parseInt(page) - 1) * parseInt(limit),
      take:    parseInt(limit),
    }),
    prisma.order.count({ where: { customerId: customer.id } })
  ]);

  res.json({ success: true, data: { orders, total, page: parseInt(page) } });
}));

// POST /customers/me/addresses
router.post("/me/addresses",
  authorize("CUSTOMER"),
  [
    body("label").notEmpty().withMessage("Label required (Home/Work/Other)"),
    body("line1").notEmpty(),
    body("city").notEmpty(),
    body("lat").isFloat(),
    body("lng").isFloat(),
  ],
  validate,
  asyncHandler(async (req, res) => {
    const { label, line1, city, lat, lng, isDefault } = req.body;
    const customer = await prisma.customer.findUnique({ where: { userId: req.user.id } });

    // If setting as default, unset others first
    if (isDefault) {
      await prisma.address.updateMany({
        where: { customerId: customer.id },
        data:  { isDefault: false }
      });
    }

    const address = await prisma.address.create({
      data: {
        customerId: customer.id,
        label, line1, city,
        lat:       parseFloat(lat),
        lng:       parseFloat(lng),
        isDefault: isDefault || false,
      }
    });
    res.status(201).json({ success: true, data: address });
  })
);

// DELETE /customers/me/addresses/:id
router.delete("/me/addresses/:id", authorize("CUSTOMER"), asyncHandler(async (req, res) => {
  const customer = await prisma.customer.findUnique({ where: { userId: req.user.id } });
  const address  = await prisma.address.findFirst({
    where: { id: req.params.id, customerId: customer.id }
  });
  if (!address) throw new AppError("Address not found.", 404);
  await prisma.address.delete({ where: { id: req.params.id } });
  res.json({ success: true, message: "Address deleted." });
}));

// PATCH /customers/me/addresses/:id/default
router.patch("/me/addresses/:id/default", authorize("CUSTOMER"), asyncHandler(async (req, res) => {
  const customer = await prisma.customer.findUnique({ where: { userId: req.user.id } });
  await prisma.address.updateMany({ where: { customerId: customer.id }, data: { isDefault: false } });
  const address = await prisma.address.update({ where: { id: req.params.id }, data: { isDefault: true } });
  res.json({ success: true, data: address });
}));

// PATCH /customers/me  — update profile
router.patch("/me", asyncHandler(async (req, res) => {
  const { name, email } = req.body;
  const data = {};
  if (name)  data.name  = name;
  if (email) data.email = email;
  const user = await prisma.user.update({ where: { id: req.user.id }, data });
  res.json({ success: true, data: user });
}));

// GET /customers/me/cart
router.get("/me/cart", authorize("CUSTOMER"), asyncHandler(async (req, res) => {
  const customer = await prisma.customer.findUnique({ where: { userId: req.user.id } });
  const items = await prisma.cartItem.findMany({
    where:   { customerId: customer.id },
    include: { item: { include: { category: { include: { restaurant: { select: { id: true, name: true } } } } } } },
  });
  const total = items.reduce((s, i) => s + i.item.price * i.quantity, 0);
  res.json({ success: true, data: { items, total, count: items.reduce((s,i) => s + i.quantity, 0) } });
}));

// POST /customers/me/cart
router.post("/me/cart",
  authorize("CUSTOMER"),
  [body("itemId").notEmpty(), body("quantity").isInt({ min: 1 })],
  validate,
  asyncHandler(async (req, res) => {
    const { itemId, quantity } = req.body;
    const customer = await prisma.customer.findUnique({ where: { userId: req.user.id } });

    const item = await prisma.menuItem.findUnique({ where: { id: itemId } });
    if (!item || !item.isAvailable) throw new AppError("Item not available.", 400);

    const cartItem = await prisma.cartItem.upsert({
      where:  { customerId_itemId: { customerId: customer.id, itemId } },
      update: { quantity },
      create: { customerId: customer.id, itemId, quantity },
    });
    res.json({ success: true, data: cartItem });
  })
);

// DELETE /customers/me/cart  — clear cart
router.delete("/me/cart", authorize("CUSTOMER"), asyncHandler(async (req, res) => {
  const customer = await prisma.customer.findUnique({ where: { userId: req.user.id } });
  await prisma.cartItem.deleteMany({ where: { customerId: customer.id } });
  res.json({ success: true, message: "Cart cleared." });
}));

// DELETE /customers/me/cart/:itemId
router.delete("/me/cart/:itemId", authorize("CUSTOMER"), asyncHandler(async (req, res) => {
  const customer = await prisma.customer.findUnique({ where: { userId: req.user.id } });
  await prisma.cartItem.deleteMany({
    where: { customerId: customer.id, itemId: req.params.itemId }
  });
  res.json({ success: true, message: "Item removed from cart." });
}));

// GET /customers/me/wallet
router.get("/me/wallet", authorize("CUSTOMER"), asyncHandler(async (req, res) => {
  const customer = await prisma.customer.findUnique({ where: { userId: req.user.id } });
  const transactions = await prisma.walletTransaction.findMany({
    where:   { customerId: customer.id },
    orderBy: { createdAt: "desc" },
    take:    30,
  });
  res.json({
    success: true,
    data: { balance: customer.walletBalance, coins: customer.coins, transactions }
  });
}));

// GET /customers  — admin only
router.get("/", authorize("SUPER_ADMIN"), asyncHandler(async (req, res) => {
  const { page = 1, limit = 20 } = req.query;
  const [customers, total] = await Promise.all([
    prisma.customer.findMany({
      include: { user: { select: { name: true, phone: true, email: true, createdAt: true } } },
      orderBy: { user: { createdAt: "desc" } },
      skip:    (parseInt(page)-1) * parseInt(limit),
      take:    parseInt(limit),
    }),
    prisma.customer.count()
  ]);
  res.json({ success: true, data: { customers, total } });
}));

module.exports = router;
